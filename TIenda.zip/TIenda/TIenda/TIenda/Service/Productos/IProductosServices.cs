﻿using TIenda.DTOs;

namespace TIenda.Service.Productos
{
    public interface IProductosServices
    {
        Task<int> PostProductos(ProductoRequest productos);

        Task<List<ProductoResponse>> GetProductos();

        Task<ProductoResponse> GetProducto(int ProductoId);

        Task<int> PutProducto(int ProductoId, ProductoRequest producto);

        Task<int> DeleteProducto(int ProductoId);
    }
}
