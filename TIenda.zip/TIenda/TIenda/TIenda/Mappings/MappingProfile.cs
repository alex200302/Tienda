﻿using TIenda.Models;
using TIenda.DTOs;
namespace TIenda.Mappings
{
    public class MappingProfile : Profile
    {
        public MappingProfile() {

            CreateMap<Producto, ProductoResponse>();

            CreateMap<Usuario, UsuarioResponse>();


            CreateMap<ProductoRequest, Producto>();
            CreateMap<UsuarioRequest Usuario>();
        }
    }
}
