﻿using TIenda.Models;

namespace TIenda.Endpoints
{
    public static class ProductorEndpoints
    {
        public static void Add( this IEndpointRouteBuilder routes)
        {
            var group = routes.MapGroup("/api/producto").WithTags("Producto");

            group.MapGet("/", async () =>
            {

            });
        }
    }
}
