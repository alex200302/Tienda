﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using TIenda.Models;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Authorization;

[ApiController]
[Route("api/[controller]")]
public class UsuariosController : ControllerBase
{
    private readonly TiendaContext _context;
    private readonly IConfiguration _configuration;  // Inyección de la configuración para usar JWT

    public UsuariosController(TiendaContext context, IConfiguration configuration)
    {
        _context = context;
        _configuration = configuration;
    }

    // GET: api/Usuarios
    [HttpGet]
    [Authorize]  // Solo los usuarios autenticados podrán acceder a esta acción
    public async Task<ActionResult<IEnumerable<Usuario>>> GetUsuarios()
    {
        try
        {
            var usuarios = await _context.Usuarios.ToListAsync();
            return Ok(usuarios);
        }
        catch (Exception ex)
        {
            // Log the exception (ex) as needed
            return StatusCode(500, "Error al obtener los usuarios.");
        }
    }

    // GET: api/Usuarios/5
    [HttpGet("{id}")]
    [Authorize]  // Requiere autenticación
    public async Task<ActionResult<Usuario>> GetUsuario(int id)
    {
        try
        {
            var usuario = await _context.Usuarios.FindAsync(id);

            if (usuario == null)
            {
                return NotFound("Usuario no encontrado.");
            }

            return Ok(usuario);
        }
        catch (Exception ex)
        {
            // Log the exception (ex) as needed
            return StatusCode(500, "Error al obtener el usuario.");
        }
    }

    // POST: api/Usuarios
    [HttpPost]
 //   [Authorize(Roles = "Admin")]  // Solo un usuario con el rol Admin puede crear usuarios
    public async Task<ActionResult<Usuario>> PostUsuario(Usuario usuario)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        try
        {
            _context.Usuarios.Add(usuario);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetUsuario), new { id = usuario.IdUsuario }, usuario);
        }
        catch (Exception ex)
        {
            // Log the exception (ex) as needed
            return StatusCode(500, "Error al crear el usuario.");
        }
    }

    // PUT: api/Usuarios/5
    [HttpPut("{id}")]
    [Authorize]  // Requiere autenticación
    public async Task<IActionResult> PutUsuario(int id, Usuario usuario)
    {
        if (id != usuario.IdUsuario)
        {
            return BadRequest("El ID del usuario no coincide.");
        }

        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        try
        {
            _context.Entry(usuario).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!UsuarioExists(id))
            {
                return NotFound("Usuario no encontrado.");
            }
            else
            {
                throw;
            }
        }
        catch (Exception ex)
        {
            // Log the exception (ex) as needed
            return StatusCode(500, "Error al actualizar el usuario.");
        }
    }

    // DELETE: api/Usuarios/5
    [HttpDelete("{id}")]
    [Authorize(Roles = "Admin")]  // Solo un Admin puede eliminar usuarios
    public async Task<IActionResult> DeleteUsuario(int id)
    {
        try
        {
            var usuario = await _context.Usuarios.FindAsync(id);
            if (usuario == null)
            {
                return NotFound("Usuario no encontrado.");
            }

            _context.Usuarios.Remove(usuario);
            await _context.SaveChangesAsync();
            return NoContent();
        }
        catch (Exception ex)
        {
            // Log the exception (ex) as needed
            return StatusCode(500, "Error al eliminar el usuario.");
        }
    }

    private bool UsuarioExists(int id)
    {
        return _context.Usuarios.Any(e => e.IdUsuario == id);
    }

    // POST: api/Usuarios/login
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest loginRequest)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        var usuario = await _context.Usuarios
            .FirstOrDefaultAsync(u => u.Email == loginRequest.Email && u.Contraseña == loginRequest.Contraseña);

        if (usuario == null)
        {
            return Unauthorized("Credenciales inválidas.");
        }

        // Generar el token JWT
        var token = GenerateJwtToken(usuario);
        return Ok(new { token });
    }

    // Método para generar el token JWT
    private string GenerateJwtToken(Usuario usuario)
    {
        var tokenHandler = new JwtSecurityTokenHandler();
        var key = Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]);

        var claims = new[]
        {
            new Claim(ClaimTypes.Name, usuario.Email),
            new Claim(ClaimTypes.Role, "User")  // Puedes ajustar el rol según el usuario
        };

        var tokenDescriptor = new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(claims),
            Expires = DateTime.UtcNow.AddMinutes(60),
            SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
            Issuer = _configuration["Jwt:Issuer"],       // Añadir el emisor
            Audience = _configuration["Jwt:Audience"]    // Añadir la audiencia
        };

        var token = tokenHandler.CreateToken(tokenDescriptor);
        return tokenHandler.WriteToken(token);
    }

    // Clase de modelo para la solicitud de login
    public class LoginRequest
    {
        public string Email { get; set; }
        public string Contraseña { get; set; }
    }
}
