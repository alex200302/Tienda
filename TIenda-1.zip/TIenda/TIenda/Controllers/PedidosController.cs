﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TIenda.Models;

[ApiController]
[Route("api/[controller]")]
public class PedidosController : ControllerBase
{
    private readonly TiendaContext _context;

    public PedidosController(TiendaContext context)
    {
        _context = context;
    }

    // GET: api/Pedidos
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Pedido>>> GetPedidos()
    {
        var pedidos = await _context.Pedidos.ToListAsync();
        return Ok(pedidos); // Devuelve la lista en formato JSON
    }

    // GET: api/Pedidos/5
    [HttpGet("{id}")]
    public async Task<ActionResult<Pedido>> GetPedido(int id)
    {
        var pedido = await _context.Pedidos.FindAsync(id);
        if (pedido == null)
        {
            return NotFound(new { message = "Pedido no encontrado." }); // Asegúrate de devolver un objeto JSON
        }

        return Ok(pedido); // Asegúrate de que esto devuelve un objeto serializable a JSON
    }

    [HttpPost]
    public async Task<ActionResult<Pedido>> PostPedido(Pedido pedido)
    {
        // Verificar si el modelo es válido
        if (!ModelState.IsValid)
        {
            return BadRequest(new { message = "Modelo no válido", errors = ModelState });
        }

        // Asegúrate de que la fecha esté en el rango correcto
        if (pedido.Fecha < new DateTime(1753, 1, 1) || pedido.Fecha > new DateTime(9999, 12, 31))
        {
            return BadRequest(new { message = "La fecha del pedido debe estar entre el 1 de enero de 1753 y el 31 de diciembre de 9999." });
        }

        _context.Pedidos.Add(pedido);
        await _context.SaveChangesAsync();

        return CreatedAtAction("GetPedido", new { id = pedido.IdPedido }, pedido);
    }

    // PUT: api/Pedidos/5
    [HttpPut("{id}")]
    public async Task<IActionResult> PutPedido(int id, Pedido pedido)
    {
        if (id != pedido.IdPedido)
        {
            return BadRequest(new { message = "El ID del pedido no coincide." }); // Asegúrate de devolver un objeto JSON
        }

        _context.Entry(pedido).State = EntityState.Modified;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!PedidoExists(id))
            {
                return NotFound(new { message = "Pedido no encontrado." }); // Asegúrate de devolver un objeto JSON
            }
            else
            {
                return StatusCode(500, new { message = "Error al actualizar el pedido." }); // Asegúrate de devolver un objeto JSON
            }
        }

        return NoContent(); // Esto está bien ya que NoContent no devuelve un cuerpo
    }

    // DELETE: api/Pedidos/5
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeletePedido(int id)
    {
        var pedido = await _context.Pedidos.FindAsync(id);
        if (pedido == null)
        {
            return NotFound(new { message = "Pedido no encontrado." }); // Asegúrate de devolver un objeto JSON
        }

        _context.Pedidos.Remove(pedido);
        await _context.SaveChangesAsync();

        return NoContent(); // Esto está bien
    }

    private bool PedidoExists(int id)
    {
        return _context.Pedidos.Any(e => e.IdPedido == id);
    }
}
