using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;
using TIenda.Models;

var builder = WebApplication.CreateBuilder(args);

// Agrega la configuraci�n de CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll",
        policy =>
        {
            policy.AllowAnyOrigin()  // Permite cualquier origen
                  .AllowAnyMethod()   // Permite cualquier m�todo (GET, POST, etc.)
                  .AllowAnyHeader();  // Permite cualquier cabecera
        });
});

// Configura Swagger con autenticaci�n JWT
builder.Services.AddSwaggerGen(options =>
{
    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "Ingrese el token JWT en el campo siguiente: **Bearer {token}**"
    });

    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new string[] {}
        }
    });
});

// Configura el contexto de base de datos para usar SQL Server (puedes cambiar a MySQL si es necesario)
builder.Services.AddDbContext<TiendaContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Agrega los servicios al contenedor (Controllers, Swagger, etc.)
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Configura la autenticaci�n JWT
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.RequireHttpsMetadata = false;  // No requiere HTTPS en los metadatos del token
    options.SaveToken = true;              // Guarda el token en el contexto de autenticaci�n
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,              // Valida el emisor del token
        ValidateAudience = true,            // Valida la audiencia del token
        ValidateLifetime = true,            // Valida la expiraci�n del token
        ValidateIssuerSigningKey = true,    // Valida la clave de firma del token
        ValidIssuer = builder.Configuration["Jwt:Issuer"],     // Emisor v�lido
        ValidAudience = builder.Configuration["Jwt:Audience"], // Audiencia v�lida
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"])) // Clave de firma
    };
});

var app = builder.Build();

// Configura Swagger solo en entorno de desarrollo
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();  // Redirige HTTP a HTTPS

// Aplica la pol�tica CORS antes de las solicitudes a la API
app.UseCors("AllowAll");

// Habilita la autenticaci�n antes de la autorizaci�n
app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();  // Mapea los endpoints de los controladores

app.Run();
